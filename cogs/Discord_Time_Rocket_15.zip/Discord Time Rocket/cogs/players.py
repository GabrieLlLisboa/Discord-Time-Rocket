import discord
from discord.ext import commands, tasks


JOGADORES_CHANNEL_ID = 1514775408124367149

STAFF_CARGOS = [
    {"nome": "Dono do Clube",      "id": 1511895253777649704, "emoji": "👑", "secao": "staff"},
    {"nome": "Sub-Dono",           "id": 1511894837790769204, "emoji": "🥈", "secao": "staff"},
    {"nome": "Diretor",            "id": 1523835085475020932, "emoji": "🎖️", "secao": "staff"},
    {"nome": "Gerente",            "id": 1523835045872275566, "emoji": "🗂️", "secao": "staff"},
    {"nome": "Moderador",          "id": 1523835010795176027, "emoji": "🔨", "secao": "staff"},
    {"nome": "Suporte",            "id": 1523833330175442954, "emoji": "🎧", "secao": "staff"},
    {"nome": "Coach",              "id": 1513356584946896946, "emoji": "📋", "secao": "staff"},
    {"nome": "Editor de vídeo",    "id": 1513240072139309317, "emoji": "🎬", "secao": "staff"},
]

# ── Ranks divididos por divisão (1, 2, 3) ────────────────────────────────
# Super Sonic Legend é o único que não tem divisão (é o topo absoluto).
RANK_SSL_ID = 1514772134327488642

RANK_TIER_EMOJIS = {
    "Super Sonic Legend": "🌌",
    "Grand Champion":     "👑",
    "Champion":           "🏅",
    "Diamante":           "💎",
    "Platina":            "🪙",
}

# ordem do melhor pro pior tier (sem contar divisão)
RANK_TIERS_ORDEM = ["Super Sonic Legend", "Grand Champion", "Champion", "Diamante", "Platina"]

# tiers que têm divisão 1/2/3 — todos, menos o Super Sonic Legend
RANK_TIERS_COM_DIVISAO = ["Grand Champion", "Champion", "Diamante", "Platina"]

CARGO_GERAL_SEM_DIVISAO_IDS = {
    "Platina":        1512305547544625273,
    "Diamante":       1512305401075466320,
    "Champion":       1512304793534861313,
    "Grand Champion": 1513343857125752992,
}

RANK_DIVISAO_IDS = {
    "Platina":        {1: 1544205321751232574, 2: 1544318465886785617, 3: 1544205635871051786},
    "Diamante":       {1: 1544318417044111430, 2: 1544206278082039890, 3: 1544207340570546226},
    "Champion":       {1: 1544318519305441330, 2: 1544207872488116284, 3: 1544208446986002542},
    "Grand Champion": {1: 1544318559994253353, 2: 1544208903233871872, 3: 1544209080053145711},
}

RANK_CARGOS = [
    {"nome": "Super Sonic Legend", "id": RANK_SSL_ID, "emoji": RANK_TIER_EMOJIS["Super Sonic Legend"], "secao": "rank"},
]
for _tier in ["Grand Champion", "Champion", "Diamante"]:
    for _div in (3, 2, 1):
        RANK_CARGOS.append({
            "nome": f"{_tier} {_div}",
            "id": RANK_DIVISAO_IDS[_tier][_div],
            "emoji": RANK_TIER_EMOJIS[_tier],
            "secao": "rank",
        })
for _div in (3, 2, 1):
    RANK_CARGOS.append({
        "nome": f"Platina {_div}",
        "id": RANK_DIVISAO_IDS["Platina"][_div],
        "emoji": RANK_TIER_EMOJIS["Platina"],
        "secao": "rank",
    })

CARGOS = STAFF_CARGOS + RANK_CARGOS

IDS_MONITORADOS  = {c["id"] for c in CARGOS}
CARGO_MAP        = {c["id"]: c for c in CARGOS}
RANK_IDS         = {c["id"] for c in CARGOS if c["secao"] == "rank"}
STAFF_IDS        = {c["id"] for c in CARGOS if c["secao"] == "staff"}

# Cargo "geral" do rank (Platina, Diamante, Champion, Grand Champion) que acompanha
# SEMPRE o cargo de divisão: quem recebe "Champion 2" recebe também "Champion".
# O Super Sonic Legend não tem divisão, então não tem cargo geral.
CARGO_GERAL_IDS = set(CARGO_GERAL_SEM_DIVISAO_IDS.values())
CARGO_GERAL_POR_DIVISAO = {
    div_id: CARGO_GERAL_SEM_DIVISAO_IDS[tier]
    for tier, divisoes in RANK_DIVISAO_IDS.items()
    for div_id in divisoes.values()
}


async def aplicar_cargo_rank(membro, novo_cargo, motivo: str) -> None:
    """Dá o cargo de divisão `novo_cargo` + o cargo geral do rank dele e tira
    os cargos de rank antigos (divisão e geral). Levanta discord.Forbidden se
    o bot não tiver permissão — quem chama decide o que avisar."""
    guild = membro.guild
    geral_id = CARGO_GERAL_POR_DIVISAO.get(novo_cargo.id)
    geral = guild.get_role(geral_id) if geral_id else None

    remover = [
        r for r in membro.roles
        if (r.id in RANK_IDS and r.id != novo_cargo.id)
        or (r.id in CARGO_GERAL_IDS and (geral is None or r.id != geral.id))
    ]
    if remover:
        await membro.remove_roles(*remover, reason=motivo)

    adicionar = [r for r in (novo_cargo, geral) if r is not None and r not in membro.roles]
    if adicionar:
        await membro.add_roles(*adicionar, reason=motivo)


async def garantir_cargo_geral(membro) -> bool:
    """Quem tem um cargo de divisão (ex.: Platina 1) SEMPRE tem o cargo geral do
    rank (Platina). Só adiciona o que falta, nunca tira nada. True se mudou algo."""
    ids = {r.id for r in membro.roles}
    faltando = {
        CARGO_GERAL_POR_DIVISAO[div_id]
        for div_id in ids & CARGO_GERAL_POR_DIVISAO.keys()
        if CARGO_GERAL_POR_DIVISAO[div_id] not in ids
    }
    cargos = [c for c in (membro.guild.get_role(i) for i in faltando) if c is not None]
    if not cargos:
        return False
    try:
        await membro.add_roles(*cargos, reason="Rank: o cargo geral acompanha o cargo da divisão")
    except discord.HTTPException as e:
        print(f"[PLAYERS] ⚠️ Não consegui dar o cargo geral de rank pra {membro}: {e}")
        return False
    return True


CARGOS_RANK      = [c for c in CARGOS if c["secao"] == "rank"]


IDS_OCULTOS = {1521890714873757707, 1514782308031533116}


def _esta_oculto(membro: discord.Member) -> bool:
    return bool(IDS_OCULTOS & {r.id for r in membro.roles})


def _membros_do_cargo(guild: discord.Guild, cargo_id: int) -> list:
    """Membros de um cargo, já filtrando bots e membros ocultos."""
    cargo = guild.get_role(cargo_id)
    if cargo is None:
        return []
    return [m for m in cargo.members if not m.bot and not _esta_oculto(m)]


def build_embed(guild: discord.Guild) -> discord.Embed:
    embed = discord.Embed(
        title="🚀  TryHarders RL — Time de Rocket League",
        color=0xD4A843,
    )

    for cargo_info in CARGOS:
        membros = sorted(
            _membros_do_cargo(guild, cargo_info["id"]),
            key=lambda m: m.display_name.lower()
        )

        if membros:
            lista = "\n".join(f"  ▸  {m.display_name}" for m in membros)
        else:
            lista = "  *— nenhum jogador —*"

        embed.add_field(
            name=f"{cargo_info['emoji']}  **{cargo_info['nome']}**  `({len(membros)})`",
            value=f"{lista}\n\u200b",
            inline=False,
        )

    total_membros = sum(1 for m in guild.members if not m.bot and not _esta_oculto(m))
    embed.set_footer(text=f"⚡ {total_membros} membros no clube  •  Atualiza a cada 5 min")
    embed.timestamp = discord.utils.utcnow()
    return embed


class SelecionarJogador(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder="1️⃣ Selecione o jogador...", min_values=1, max_values=1, row=0)

    async def callback(self, interaction: discord.Interaction):
        view: "SelecaoRankView" = self.view
        await interaction.response.defer(ephemeral=True)
        alvo = self.values[0]
        if not isinstance(alvo, discord.Member):
            alvo = interaction.guild.get_member(alvo.id) or alvo
        view.jogador = alvo
        await view.tentar_executar(interaction)


class SelecionarRank(discord.ui.Select):
    def __init__(self):
        opcoes = [
            discord.SelectOption(label=c["nome"], value=str(c["id"]), emoji=c["emoji"])
            for c in CARGOS_RANK
        ]
        super().__init__(placeholder="2️⃣ Selecione o novo rank...", min_values=1, max_values=1, options=opcoes, row=1)

    async def callback(self, interaction: discord.Interaction):
        view: "SelecaoRankView" = self.view
        await interaction.response.defer(ephemeral=True)
        view.novo_rank_id = int(self.values[0])
        await view.tentar_executar(interaction)


class SelecaoRankView(discord.ui.View):
    """Aparece (ephemeral) depois que a staff clica em Subir/Descer no painel.
    Só executa quando jogador E novo rank já foram escolhidos — assim o bot
    sempre acerta a mensagem, sem depender de adivinhar pelo diff de cargos."""

    def __init__(self, tipo: str):
        super().__init__(timeout=180)
        self.tipo = tipo
        self.jogador: discord.Member | None = None
        self.novo_rank_id: int | None = None
        self.add_item(SelecionarJogador())
        self.add_item(SelecionarRank())

    async def tentar_executar(self, interaction: discord.Interaction):
        if self.jogador is None or self.novo_rank_id is None:
            faltando = "o jogador" if self.jogador is None else "o novo rank"
            await interaction.followup.send(f"☑️ Escolha registrada. Ainda falta selecionar {faltando}.", ephemeral=True)
            return

        guild = interaction.guild
        novo_info = CARGO_MAP[self.novo_rank_id]
        novo_cargo = guild.get_role(self.novo_rank_id)
        if novo_cargo is None:
            await interaction.followup.send("⚠️ Esse cargo de rank não existe mais no servidor.", ephemeral=True)
            return

        cargos_rank_atuais = [r for r in self.jogador.roles if r.id in RANK_IDS]
        antigo_info = CARGO_MAP.get(cargos_rank_atuais[0].id) if cargos_rank_atuais else None

        try:
            await aplicar_cargo_rank(self.jogador, novo_cargo, f"Rank atualizado via !setup-rank ({self.tipo})")
        except discord.Forbidden:
            await interaction.followup.send("❌ Não tenho permissão pra alterar os cargos desse jogador.", ephemeral=True)
            return

        channel = interaction.client.get_channel(JOGADORES_CHANNEL_ID)
        if channel is not None:
            if self.tipo == "subir":
                if antigo_info:
                    msg = (
                        f"⬆️ **{self.jogador.display_name}** upou do rank {antigo_info['emoji']} **{antigo_info['nome']}** "
                        f"para o rank {novo_info['emoji']} **{novo_info['nome']}**!"
                    )
                else:
                    msg = f"🎉 **{self.jogador.display_name}** entrou no clube com o rank {novo_info['emoji']} **{novo_info['nome']}**!"
            else:
                if antigo_info:
                    msg = (
                        f"⬇️ **{self.jogador.display_name}** desceu do rank {antigo_info['emoji']} **{antigo_info['nome']}** "
                        f"para o rank {novo_info['emoji']} **{novo_info['nome']}**."
                    )
                else:
                    msg = f"📉 **{self.jogador.display_name}** entrou no rank {novo_info['emoji']} **{novo_info['nome']}**."

            notif = await channel.send(msg)
            await notif.delete(delay=300)

            players_cog = interaction.client.get_cog("Players")
            if players_cog:
                await players_cog._editar_ou_criar(channel)

        await interaction.followup.send(
            f"✅ Rank de **{self.jogador.display_name}** atualizado pra {novo_info['emoji']} **{novo_info['nome']}**! "
            f"Mensagem enviada em {channel.mention if channel else '#canal de jogadores'}.",
            ephemeral=True,
        )
        self.stop()


class PainelRankView(discord.ui.View):
    """Painel fixo enviado pelo comando !setup-rank."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Subir de Rank", emoji="⬆️", style=discord.ButtonStyle.success, custom_id="players_rank_subir")
    async def subir(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "**⬆️ Subida de rank**\nEscolha o jogador e o novo rank abaixo:",
            view=SelecaoRankView("subir"),
            ephemeral=True,
        )

    @discord.ui.button(label="Descer de Rank", emoji="⬇️", style=discord.ButtonStyle.danger, custom_id="players_rank_descer")
    async def descer(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "**⬇️ Descida de rank**\nEscolha o jogador e o novo rank abaixo:",
            view=SelecaoRankView("descer"),
            ephemeral=True,
        )


class Players(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot        = bot
        self.message_id = None
        self.bot.add_view(PainelRankView())
        self.atualizar_lista.start()
        self.sincronizar_cargos_gerais.start()

    def cog_unload(self):
        self.atualizar_lista.cancel()
        self.sincronizar_cargos_gerais.cancel()

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        # rank: mexeu em cargo? garante que quem tem a divisão (Platina 1) também tem o geral (Platina)
        if before.roles != after.roles:
            await garantir_cargo_geral(after)

        cargos_antes  = {r.id for r in before.roles}
        cargos_depois = {r.id for r in after.roles}
        ganhou  = (cargos_depois - cargos_antes) & STAFF_IDS
        perdeu  = (cargos_antes - cargos_depois) & STAFF_IDS
        if not ganhou and not perdeu:
            return
        channel = self.bot.get_channel(JOGADORES_CHANNEL_ID)
        if channel is None:
            return

        linhas = []
        for cid in ganhou:
            info = CARGO_MAP[cid]
            linhas.append(f"📈 **{after.display_name}** subiu para {info['emoji']} **{info['nome']}**!")
        for cid in perdeu:
            info = CARGO_MAP[cid]
            linhas.append(f"📉 **{after.display_name}** saiu de {info['emoji']} **{info['nome']}**.")

        if linhas:
            notif = await channel.send("\n".join(linhas))
            await self._editar_ou_criar(channel)
            await notif.delete(delay=300)

    @tasks.loop(minutes=5)
    async def atualizar_lista(self):
        await self.bot.wait_until_ready()
        channel = self.bot.get_channel(JOGADORES_CHANNEL_ID)
        if channel is None:
            print(f"[PLAYERS] ⚠️  Canal {JOGADORES_CHANNEL_ID} não encontrado.")
            return
        try:
            await self._editar_ou_criar(channel)
        except Exception as e:


            print(f"[PLAYERS] ⚠️ Erro ao atualizar lista de jogadores: {e}")

    @atualizar_lista.before_loop
    async def antes_do_loop(self):
        await self.bot.wait_until_ready()

    @tasks.loop(minutes=10)
    async def sincronizar_cargos_gerais(self):
        """Varredura: conserta quem já está com a divisão e sem o cargo geral (cargo
        dado na mão, bot offline na hora, etc.). O listener acima cuida do dia a dia."""
        corrigidos = 0
        vistos = set()
        for guild in self.bot.guilds:
            for div_id in CARGO_GERAL_POR_DIVISAO:
                cargo = guild.get_role(div_id)
                if cargo is None:
                    continue
                for membro in list(cargo.members):
                    if membro.bot or membro.id in vistos:
                        continue
                    vistos.add(membro.id)
                    if await garantir_cargo_geral(membro):
                        corrigidos += 1
        if corrigidos:
            print(f"[PLAYERS] 🏷️ Cargo geral de rank corrigido pra {corrigidos} jogador(es).")

    @sincronizar_cargos_gerais.before_loop
    async def antes_sincronizar_cargos(self):
        await self.bot.wait_until_ready()

    async def _editar_ou_criar(self, channel: discord.TextChannel):
        embed = build_embed(channel.guild)
        if self.message_id:
            try:
                msg = await channel.fetch_message(self.message_id)
                await msg.edit(embed=embed)
                print("[PLAYERS] 🔄 Lista atualizada.")
                return
            except discord.NotFound:
                self.message_id = None
        async for msg in channel.history(limit=20):
            if msg.author == self.bot.user and msg.embeds:
                if "TryHarders" in (msg.embeds[0].title or ""):
                    self.message_id = msg.id
                    await msg.edit(embed=embed)
                    return
        nova = await channel.send(embed=embed)
        self.message_id = nova.id
        print(f"[PLAYERS] ✅ Lista criada no canal #{channel.name}.")

    @commands.command(name="atualizarjogadores")
    @commands.has_permissions(administrator=True)
    async def forcar_atualizacao(self, ctx: commands.Context):
        channel = self.bot.get_channel(JOGADORES_CHANNEL_ID)
        await self._editar_ou_criar(channel)
        await ctx.send("✅ Lista de jogadores atualizada!", delete_after=4)

    @commands.command(name="setup-rank")
    @commands.has_permissions(administrator=True)
    async def setup_rank(self, ctx: commands.Context):
        """Envia o painel de atualização de rank (Subir/Descer) neste canal."""
        embed = discord.Embed(
            title="🎮 Painel de Atualização de Rank",
            description=(
                "Use os botões abaixo quando um jogador **subir** ou **descer** de rank.\n\n"
                "Você escolhe o jogador e o novo rank, o bot troca o cargo automaticamente "
                "e manda a mensagem certinha no canal de jogadores — sem depender de adivinhar "
                "a troca de cargo sozinho."
            ),
            color=0xD4A843,
        )
        await ctx.send(embed=embed, view=PainelRankView())

    @setup_rank.error
    async def setup_rank_error(self, ctx: commands.Context, error: commands.CommandError):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ Apenas **Administradores** podem usar este comando.", delete_after=5)

    @forcar_atualizacao.error
    async def forcar_atualizacao_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ Apenas **Administradores** podem usar este comando.", delete_after=5)


async def setup(bot: commands.Bot):
    await bot.add_cog(Players(bot))
