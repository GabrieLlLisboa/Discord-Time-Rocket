import re
import time
from datetime import datetime, timedelta, timezone

import discord
from discord.ext import commands, tasks
from discord import app_commands
from cogs.backup import ler, salvar, agora_str
from cogs import mod_utils as mu
from cogs.players import CARGOS_RANK, CARGO_GERAL_SEM_DIVISAO_IDS, RANK_DIVISAO_IDS, RANK_TIER_EMOJIS

AMISTOSOS_CHANNEL_ID = 1514778555970621531


CATEGORIA_VOZ_AMISTOSOS_ID = 1511912206055506001


CANAIS_VOZ_POS_AMISTOSO = [1514777010293964830, 1532926276464279563]

FUSO_BRASILIA = timezone(timedelta(hours=-3))


_PADRAO_DATA_HORA = re.compile(
    r"(?P<dia>\d{1,2})[/\-](?P<mes>\d{1,2})(?:[/\-](?P<ano>\d{2,4}))?"
    r".*?"
    r"(?P<hora>\d{1,2})[:h](?P<minuto>\d{2})?"
)

DIAS_SEMANA = ["Hoje", "Amanhã", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"]

_DIA_SEMANA_INDICE = {
    "Segunda-feira": 0, "Terça-feira": 1, "Quarta-feira": 2, "Quinta-feira": 3,
    "Sexta-feira": 4, "Sábado": 5, "Domingo": 6,
}

_PADRAO_HORARIO = re.compile(r"(?P<hora>\d{1,2})[:h](?P<minuto>\d{2})?")


def _parse_data_hora(texto: str, agora_local: datetime | None = None) -> float | None:
    """Tenta extrair um timestamp real de um texto livre de data/hora, pra
    dar pra agendar os lembretes do amistoso. Retorna None se não conseguir
    reconhecer o formato — nesse caso o amistoso é criado normalmente, só
    que sem lembretes automáticos."""
    m = _PADRAO_DATA_HORA.search(texto)
    if not m:
        return None
    try:
        dia = int(m.group("dia"))
        mes = int(m.group("mes"))
        hora = int(m.group("hora"))
        minuto = int(m.group("minuto") or 0)
        if not (1 <= dia <= 31 and 1 <= mes <= 12 and 0 <= hora <= 23 and 0 <= minuto <= 59):
            return None

        agora_local = agora_local or datetime.now(FUSO_BRASILIA)
        ano_str = m.group("ano")
        if ano_str:
            ano = int(ano_str)
            if ano < 100:
                ano += 2000
        else:
            ano = agora_local.year

        dt = datetime(ano, mes, dia, hora, minuto, tzinfo=FUSO_BRASILIA)


        if not ano_str and dt < agora_local - timedelta(days=1):
            dt = dt.replace(year=ano + 1)

        return dt.timestamp()
    except ValueError:
        return None


def _calcular_data_hora(dia_semana: str, horario: str, agora_local: datetime | None = None) -> tuple[str, float | None]:
    """Recebe um dia da semana (ou 'Hoje'/'Amanhã') + um horário livre tipo
    '20h00', e devolve (texto_amigavel, timestamp_ou_None) já calculando a
    próxima data real que cai nesse dia — sempre olhando pra frente
    (nunca agenda um dia que já passou nessa semana)."""
    agora_local = agora_local or datetime.now(FUSO_BRASILIA)
    horario = (horario or "").strip()

    if dia_semana == "Hoje":
        data_alvo = agora_local.date()
    elif dia_semana == "Amanhã":
        data_alvo = (agora_local + timedelta(days=1)).date()
    else:
        alvo_idx = _DIA_SEMANA_INDICE.get(dia_semana)
        if alvo_idx is None:
            data_alvo = None
        else:
            dias_a_frente = (alvo_idx - agora_local.weekday()) % 7
            data_alvo = (agora_local + timedelta(days=dias_a_frente)).date()

    m = _PADRAO_HORARIO.search(horario)
    hora_valida = False
    hora = minuto = 0
    if m:
        hora = int(m.group("hora"))
        minuto = int(m.group("minuto") or 0)
        hora_valida = 0 <= hora <= 23 and 0 <= minuto <= 59

    dt = None
    if data_alvo and hora_valida:
        dt = datetime(data_alvo.year, data_alvo.month, data_alvo.day, hora, minuto, tzinfo=FUSO_BRASILIA)
        if dia_semana not in ("Hoje", "Amanhã") and dt < agora_local:
            dt += timedelta(days=7)
            data_alvo = dt.date()

    texto = dia_semana
    if data_alvo:
        texto += f" ({data_alvo.strftime('%d/%m')})"
    if horario:
        texto += f" às {horario}"

    return texto, (dt.timestamp() if dt else None)


ADMIN_ROLE_IDS = {
    1511895253777649704,
    1511894837790769204,
}

# Ranks (com divisão 1/2/3, exceto Super Sonic Legend) vindos direto de
# cogs/players.py — fonte única de verdade — + Ouro, que só existe aqui
# pra permitir marcar amistoso contra times desse rank.
RANKS = {c["nome"]: c["id"] for c in CARGOS_RANK}
RANKS["Ouro"] = 1512571913849933956

RANK_EMOJIS = {c["nome"]: c["emoji"] for c in CARGOS_RANK}
RANK_EMOJIS["Ouro"] = "🥇"

# Cargo "geral" de cada rank (Platina, Diamante, Champion, Grand Champion) também vale
# pro amistoso: marca todo mundo do tier. (Quem tem a divisão sempre tem o geral.)
for _tier, _geral_id in CARGO_GERAL_SEM_DIVISAO_IDS.items():
    RANKS[_tier] = _geral_id
    RANK_EMOJIS[_tier] = RANK_TIER_EMOJIS[_tier]

# cargo (geral ou de divisão) -> tier a que pertence
TIER_POR_CARGO_ID = {}
for _tier, _divs in RANK_DIVISAO_IDS.items():
    TIER_POR_CARGO_ID[CARGO_GERAL_SEM_DIVISAO_IDS[_tier]] = _tier
    for _rid in _divs.values():
        TIER_POR_CARGO_ID[_rid] = _tier

# máximo de cargos num amistoso (limite de menções/tamanho do embed do Discord)
MAX_CARGOS_AMISTOSO = 30


# Divisões do Champion: se quem anuncia marcar as três (C1, C2 e C3), o
# amistoso é tratado como "Champion" (todos os ranks Champion) — pra não
# ficar "Champion 1 + Champion 2 + Champion 3" repetido em tudo.
CHAMPION_DIVISOES_IDS = {RANKS[f"Champion {d}"] for d in (1, 2, 3)}


def rank_info(role: discord.Role):
    for nome, rid in RANKS.items():
        if role.id == rid:
            return nome, RANK_EMOJIS[nome]
    return None


def montar_ranks_display(ranks_ids: list) -> tuple[list, list]:
    """(nomes, emojis) pra mostrar no anúncio. Se o tier está completo (marcou o cargo
    geral OU as 3 divisões), mostra só o nome do tier: Champion 1+2+3 -> "Champion"."""
    ids = set(ranks_ids)
    nomes, emojis, tiers_usados = [], [], set()
    for rid in ranks_ids:
        tier = TIER_POR_CARGO_ID.get(rid)
        completo = tier is not None and (
            CARGO_GERAL_SEM_DIVISAO_IDS[tier] in ids or set(RANK_DIVISAO_IDS[tier].values()) <= ids
        )
        if completo:
            if tier not in tiers_usados:
                tiers_usados.add(tier)
                nomes.append(tier)
                emojis.append(RANK_TIER_EMOJIS[tier])
            continue
        nome, emoji = rank_info_por_id(rid)
        nomes.append(nome)
        emojis.append(emoji)
    return nomes, emojis


def rank_info_por_id(rid: int):
    for nome, rank_id in RANKS.items():
        if rank_id == rid:
            return nome, RANK_EMOJIS[nome]
    return None


def extrair_cargos_extras(guild: discord.Guild, texto: str) -> tuple[list, str | None]:
    """Lê o campo `mais_cargos` do /amistoso: menções (@cargo) ou IDs, separados por
    espaço, vírgula ou linha. Devolve (cargos, erro)."""
    if not texto or not texto.strip():
        return [], None
    padrao = r"<@&(\d{15,22})>|(?<!\d)(\d{17,22})(?!\d)"
    ids = []
    for m_id, id_solto in re.findall(padrao, texto):
        valor = int(m_id or id_solto)
        if valor not in ids:
            ids.append(valor)
    sobra = re.sub(padrao, "", texto).strip(" ,;+\n\t")
    if sobra or not ids:
        return [], ("❌ Não entendi **mais_cargos**. Marque os cargos com @ (ou cole os IDs), "
                    "separados por espaço. Ex: `@Platina 1 @Platina 2 @Diamante 3`.")
    cargos = []
    for rid in ids:
        cargo = guild.get_role(rid)
        if cargo is None:
            return [], f"❌ O cargo com ID `{rid}` não existe nesse servidor."
        cargos.append(cargo)
    return cargos, None


def _construir_lista_confirmados(guild: discord.Guild, ids_confirmados: list) -> str:
    """Monta o texto da lista de confirmados SEMPRE a partir dos IDs
    salvos no JSON (fonte única de verdade) — nunca de uma lista guardada
    em memória, que pode ficar desincronizada (ex: alguém sai e a lista
    em memória de outra view não fica sabendo)."""
    linhas = []
    for mid in ids_confirmados:
        membro = guild.get_member(mid)
        nome = membro.display_name if membro else f"Usuário {mid}"
        linhas.append(f"  ▸  {nome}")
    return "\n".join(linhas)


async def _atualizar_embed_confirmados(mensagem: discord.Message, guild: discord.Guild, ids_confirmados: list):
    """Reconstrói o campo '✅ Jogadores Confirmados' do embed de anúncio a
    partir da lista canônica de IDs (JSON), e salva o embed editado."""
    if not mensagem.embeds:
        return
    embed = mensagem.embeds[0]
    outros_campos = [f for f in embed.fields if not f.name.startswith("✅  Jogadores Confirmados")]
    embed.clear_fields()
    for f in outros_campos:
        embed.add_field(name=f.name, value=f.value, inline=f.inline)
    lista = _construir_lista_confirmados(guild, ids_confirmados)
    embed.add_field(
        name=f"✅  Jogadores Confirmados  `({len(ids_confirmados)})`",
        value=lista if lista else "  *— ninguém ainda —*",
        inline=False,
    )
    try:
        await mensagem.edit(embed=embed)
    except discord.HTTPException as e:
        print(f"[AMISTOSO] ⚠️ Erro ao atualizar embed de confirmados: {e}")


class SairAmistosoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🚪  Sair do Amistoso", style=discord.ButtonStyle.danger, custom_id="sair_amistoso")
    async def sair(self, interaction: discord.Interaction, button: discord.ui.Button):
        membro = interaction.user
        canal  = interaction.channel

        await canal.set_permissions(membro, overwrite=None)

        amistosos = ler("amistosos")
        amistoso_atual = None
        for a in amistosos:
            if a.get("canal_id") == canal.id:
                if membro.id in a["confirmados"]:
                    a["confirmados"].remove(membro.id)
                amistoso_atual = a
                break
        salvar("amistosos", amistosos)


        if amistoso_atual:
            canal_voz_id = amistoso_atual.get("canal_voz_id")
            if canal_voz_id:
                canal_voz = interaction.client.get_channel(canal_voz_id)
                if canal_voz:
                    try:
                        await canal_voz.set_permissions(membro, overwrite=None)
                    except discord.HTTPException as e:
                        print(f"[AMISTOSO] ⚠️ Erro ao remover acesso do canal de voz pra {membro}: {e}")


        if amistoso_atual and amistoso_atual.get("msg_anuncio_id"):
            canal_anuncio = interaction.client.get_channel(AMISTOSOS_CHANNEL_ID)
            if canal_anuncio:
                try:
                    msg_anuncio = await canal_anuncio.fetch_message(amistoso_atual["msg_anuncio_id"])
                    await _atualizar_embed_confirmados(msg_anuncio, interaction.guild, amistoso_atual["confirmados"])
                except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                    pass

        await canal.send(f"🚪 **{membro.display_name}** saiu do amistoso.")
        await interaction.response.send_message("✅ Você saiu do amistoso e perdeu o acesso ao canal.", ephemeral=True)
        print(f"[AMISTOSO] 🚪 {membro} saiu do amistoso no canal #{canal.name}.")


class ConfirmarPresencaView(discord.ui.View):
    def __init__(self, rank_alvo: str, rank_id: int, canal_amistoso_id: int, rank_ids_extras: list = None):
        super().__init__(timeout=None)
        self.rank_alvo         = rank_alvo
        self.rank_id           = rank_id
        self.rank_ids_extras   = rank_ids_extras or [rank_id]
        self.canal_amistoso_id = canal_amistoso_id


    def _buscar_amistoso(self, amistosos: list):
        for a in amistosos:
            if a.get("canal_id") == self.canal_amistoso_id:
                return a
        return None

    @discord.ui.button(label="✅  Confirmar Presença", style=discord.ButtonStyle.success, custom_id="confirmar_amistoso")
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        membro     = interaction.user
        ids_cargos = {r.id for r in membro.roles}

        if not any(rid in ids_cargos for rid in self.rank_ids_extras):
            await interaction.response.send_message(
                f"❌ Apenas jogadores **{self.rank_alvo}** podem confirmar presença neste amistoso.",
                ephemeral=True
            )
            return

        amistosos = ler("amistosos")
        amistoso = self._buscar_amistoso(amistosos)
        if amistoso is None:
            await interaction.response.send_message("⚠️ Não achei os dados desse amistoso — fala com um admin.", ephemeral=True)
            return

        if membro.id in amistoso["confirmados"]:
            await interaction.response.send_message("⚠️ Você já confirmou presença neste amistoso!", ephemeral=True)
            return

        amistoso["confirmados"].append(membro.id)
        salvar("amistosos", amistosos)


        await _atualizar_embed_confirmados(interaction.message, interaction.guild, amistoso["confirmados"])


        canal_amistoso = interaction.client.get_channel(self.canal_amistoso_id)
        if canal_amistoso:
            await canal_amistoso.set_permissions(
                membro, view_channel=True, send_messages=True, read_message_history=True
            )
            await canal_amistoso.send(f"✅ {membro.mention} confirmou presença!")


        canal_voz_id = amistoso.get("canal_voz_id")
        if canal_voz_id:
            canal_voz = interaction.client.get_channel(canal_voz_id)
            if canal_voz:
                try:
                    await canal_voz.set_permissions(membro, view_channel=True, connect=True, speak=True)
                except discord.HTTPException as e:
                    print(f"[AMISTOSO] ⚠️ Erro ao liberar canal de voz pra {membro}: {e}")

        await interaction.response.send_message(
            f"✅ Presença confirmada! Você agora tem acesso a {canal_amistoso.mention if canal_amistoso else 'o canal do amistoso'}. 🚀",
            ephemeral=True
        )
        print(f"[AMISTOSO] ✅ {membro} confirmou presença.")


async def criar_amistoso(
    interaction: discord.Interaction,
    adversario: str,
    dia_semana: str,
    horario: str,
    rank1: discord.Role,
    info_extra: str,
    rank2: discord.Role = None,
    rank3: discord.Role = None,
    outros: list = None,
):
    guild = interaction.guild

    # criar os canais abaixo demora mais que os 3s que o Discord dá pra responder:
    # confirma o comando já, e responde tudo pelo followup
    await interaction.response.defer(ephemeral=True)

    canal_anuncio = interaction.client.get_channel(AMISTOSOS_CHANNEL_ID)
    if canal_anuncio is None:
        # antes essa checagem vinha depois de criar os canais e deixava canal órfão
        await interaction.followup.send("❌ Canal de amistosos não encontrado.", ephemeral=True)
        return

    ranks_ids = []
    for cargo in [rank1, rank2, rank3, *(outros or [])]:
        if cargo is None or cargo.id in ranks_ids:
            continue
        if rank_info(cargo) is None:
            await interaction.followup.send(f"❌ O cargo {cargo.mention} não é um rank válido.", ephemeral=True)
            return
        ranks_ids.append(cargo.id)
    if len(ranks_ids) > MAX_CARGOS_AMISTOSO:
        await interaction.followup.send(
            f"❌ No máximo {MAX_CARGOS_AMISTOSO} cargos por amistoso (limite de menções do Discord).", ephemeral=True
        )
        return

    # tier completo (cargo geral ou as 3 divisões) vira só o nome do tier no anúncio;
    # ranks_ids continua com todos os cargos (menção e confirmação de presença)
    nomes_ranks, emojis_ranks = montar_ranks_display(ranks_ids)

    rank_display = " + ".join(f"{e} {n}" for e, n in zip(emojis_ranks, nomes_ranks))
    mencao_str   = " ".join(guild.get_role(rid).mention for rid in ranks_ids if guild.get_role(rid))
    rank_salvo   = " + ".join(nomes_ranks)

    data_hora, data_hora_ts = _calcular_data_hora(dia_semana, horario)

    nome_canal = "amistoso-" + "".join(c if c.isalnum() or c == "-" else "-" for c in adversario.lower().strip())
    nome_canal = nome_canal[:50]

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        guild.me:           discord.PermissionOverwrite(view_channel=True, send_messages=True),
    }
    for admin_role_id in ADMIN_ROLE_IDS:
        admin_role = guild.get_role(admin_role_id)
        if admin_role:
            overwrites[admin_role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)


    overwrites_voz = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False, connect=False),
        guild.me:           discord.PermissionOverwrite(view_channel=True, connect=True, speak=True),
    }
    for admin_role_id in ADMIN_ROLE_IDS:
        admin_role = guild.get_role(admin_role_id)
        if admin_role:
            overwrites_voz[admin_role] = discord.PermissionOverwrite(view_channel=True, connect=True, speak=True)

    canal_ref      = guild.get_channel(AMISTOSOS_CHANNEL_ID)
    categoria      = canal_ref.category if canal_ref else None
    canal_amistoso = await guild.create_text_channel(
        name=nome_canal, overwrites=overwrites, category=categoria,
        reason=f"Amistoso vs {adversario} criado por {interaction.user}"
    )

    categoria_voz  = guild.get_channel(CATEGORIA_VOZ_AMISTOSOS_ID)
    nome_canal_voz = f"⚽│Amistoso {adversario}"[:100]
    canal_voz = await guild.create_voice_channel(
        name=nome_canal_voz, overwrites=overwrites_voz, category=categoria_voz,
        reason=f"Canal de voz do amistoso vs {adversario} criado por {interaction.user}"
    )

    embed = discord.Embed(title="⚽  AMISTOSO ANUNCIADO", color=0xD4A843)
    embed.add_field(name="\u200b", value="```╔══════════  📋  DETALHES  ══════════╗```", inline=False)
    embed.add_field(name="🆚  Adversário",  value=f"**{adversario}**", inline=True)
    embed.add_field(name="📅  Data / Hora", value=f"**{data_hora}**",  inline=True)
    embed.add_field(name="🏅  Rank",        value=rank_display,        inline=True)
    if info_extra:
        embed.add_field(name="📝  Informações", value=info_extra, inline=False)
    embed.add_field(
        name="\u200b",
        value=(
            f"🔔 {mencao_str} — Confirme sua presença abaixo!\n"
            f"📁 Canal do amistoso: {canal_amistoso.mention}\n"
            f"🔊 Canal de voz: {canal_voz.mention}"
        ),
        inline=False
    )
    embed.set_footer(text=f"Anunciado por {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
    embed.timestamp = discord.utils.utcnow()

    view_conf   = ConfirmarPresencaView(rank_alvo=rank_salvo, rank_id=ranks_ids[0], canal_amistoso_id=canal_amistoso.id, rank_ids_extras=ranks_ids)
    msg_anuncio = await canal_anuncio.send(content=mencao_str, embed=embed, view=view_conf)

    cog = interaction.client.cogs.get("Friendly")
    if cog:
        cog.registrar(msg_anuncio.id, canal_amistoso.id, canal_voz.id)

    amistosos = ler("amistosos")
    amistosos.append({
        "id": len(amistosos) + 1, "adversario": adversario, "data": data_hora,
        "rank": rank_salvo, "resultado": None, "placar": "", "confirmados": [],
        "canal_id": canal_amistoso.id, "canal_voz_id": canal_voz.id, "criado_em": agora_str(),
        "msg_anuncio_id": msg_anuncio.id,
        "rank_id": ranks_ids[0],
        "rank_ids_extras": ranks_ids,
        "data_hora_ts": data_hora_ts,
        "lembretes_enviados": [],
    })
    salvar("amistosos", amistosos)

    embed_canal = discord.Embed(
        title=f"⚽ Amistoso vs {adversario}",
        description=(
            f"Bem-vindos ao canal do amistoso!\n\n"
            f"**🏅 Rank:** {rank_display}\n"
            f"**📅 Data:** {data_hora}\n"
            f"**🔊 Voz:** {canal_voz.mention}\n"
            + (f"**📝 Info:** {info_extra}\n" if info_extra else "") +
            "\nSe quiser desistir, clique no botão abaixo."
        ),
        color=0xD4A843
    )
    await canal_amistoso.send(embed=embed_canal, view=SairAmistosoView())
    await canal_amistoso.send(f"🔊 Canal de voz do amistoso: {canal_voz.mention}")

    if data_hora_ts is None:
        aviso_lembretes = (
            "\n⚠️ Não consegui reconhecer o horário digitado pra agendar os lembretes automáticos "
            "(use algo tipo `20h00` ou `20:00`). O amistoso foi criado normalmente, só sem os avisos automáticos."
        )
    else:
        aviso_lembretes = ""

    await interaction.followup.send(
        f"✅ Amistoso anunciado! Canal criado: {canal_amistoso.mention}{aviso_lembretes}", ephemeral=True
    )
    print(f"[AMISTOSO] ✅ {interaction.user} anunciou amistoso vs {adversario} — {rank_salvo}")


_MARCOS_LEMBRETE = [
    (5 * 3600, "5h_canal", "canal"),
    (1 * 3600, "1h_dm", "dm"),
    (30 * 60, "30min_ambos", "ambos"),
    (10 * 60, "10min_ambos", "ambos"),
]

_TEXTO_TEMPO = {
    "5h_canal": "5 horas",
    "1h_dm": "1 hora",
    "30min_ambos": "30 minutos",
    "10min_ambos": "10 minutos",
}


_AVISO_SAIR_CANAL = (
    "\n\n📌 Gostaríamos de lembrar que, se você não pode participar, aperte "
    "no botão de sair anexado a esta mensagem — isso torna tudo mais organizado."
)
_AVISO_SAIR_DM = (
    "\n\n📌 Gostaríamos de lembrar que, se você não pode participar, aperte "
    "no botão de sair no canal do amistoso — isso torna tudo mais organizado."
)


class Friendly(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.amistoso_map: dict[int, tuple[int, int | None]] = {}


        self.bot.add_view(SairAmistosoView())

        for a in ler("amistosos"):
            if a.get("resultado") is not None:
                continue

            msg_id       = a.get("msg_anuncio_id")
            canal_id     = a.get("canal_id")
            canal_voz_id = a.get("canal_voz_id")
            rank_id      = a.get("rank_id")
            if msg_id is None or canal_id is None:


                continue

            view = ConfirmarPresencaView(
                rank_alvo=a.get("rank", ""),
                rank_id=rank_id,
                canal_amistoso_id=canal_id,
                rank_ids_extras=a.get("rank_ids_extras") or ([rank_id] if rank_id else []),
            )
            self.bot.add_view(view, message_id=msg_id)
            self.amistoso_map[msg_id] = (canal_id, canal_voz_id)

        self.lembretes_amistoso.start()

    def cog_unload(self):
        self.lembretes_amistoso.cancel()

    def registrar(self, message_id: int, canal_id: int, canal_voz_id: int | None = None):
        self.amistoso_map[message_id] = (canal_id, canal_voz_id)


    @tasks.loop(minutes=1)
    async def lembretes_amistoso(self):
        await self.bot.wait_until_ready()
        agora_ts = time.time()
        amistosos = ler("amistosos")
        mudou = False

        for amistoso in amistosos:
            if amistoso.get("resultado") is not None:
                continue

            ts = amistoso.get("data_hora_ts")
            if not ts or agora_ts >= ts:


                continue

            confirmados = amistoso.get("confirmados") or []
            if not confirmados:
                continue

            enviados = amistoso.setdefault("lembretes_enviados", [])

            for segundos, chave, destino in _MARCOS_LEMBRETE:
                if chave in enviados:
                    continue

                tempo_restante = ts - agora_ts
                if tempo_restante > segundos:
                    continue


                if tempo_restante < segundos - (15 * 60):
                    enviados.append(chave)
                    mudou = True
                    continue

                await self._enviar_lembrete(amistoso, destino, chave)
                enviados.append(chave)
                mudou = True

        if mudou:
            salvar("amistosos", amistosos)

    @lembretes_amistoso.before_loop
    async def antes_lembretes_amistoso(self):
        await self.bot.wait_until_ready()

    async def _enviar_lembrete(self, amistoso: dict, destino: str, chave: str):
        tempo_texto = _TEXTO_TEMPO.get(chave, "pouco tempo")
        adversario  = amistoso.get("adversario", "adversário")
        data_hora   = amistoso.get("data", "")
        confirmados = amistoso.get("confirmados") or []
        canal_id    = amistoso.get("canal_id")

        if destino in ("canal", "ambos"):
            canal = self.bot.get_channel(canal_id) if canal_id else None
            if canal is not None:
                mencoes = " ".join(f"<@{uid}>" for uid in confirmados)
                try:
                    await canal.send(
                        f"⏰ **Faltam {tempo_texto} pro amistoso vs {adversario}!** ({data_hora})\n{mencoes}"
                        f"{_AVISO_SAIR_CANAL}",
                        view=SairAmistosoView(),
                    )
                except discord.HTTPException as e:
                    print(f"[AMISTOSO] ⚠️ Erro ao mandar lembrete no canal: {e}")

        if destino in ("dm", "ambos"):
            for uid in confirmados:
                usuario = self.bot.get_user(uid)
                if usuario is None:
                    try:
                        usuario = await self.bot.fetch_user(uid)
                    except discord.HTTPException:
                        continue
                try:
                    await usuario.send(
                        f"⏰ **Faltam {tempo_texto} pro seu amistoso vs {adversario}!** ({data_hora})\n"
                        f"Não esquece de aparecer! 🚀"
                        f"{_AVISO_SAIR_DM}"
                    )
                except discord.Forbidden:
                    pass
                except discord.HTTPException as e:
                    print(f"[AMISTOSO] ⚠️ Erro ao mandar lembrete por DM pra {uid}: {e}")


    async def _mover_membros_pos_amistoso(self, canal_voz: discord.VoiceChannel):
        await mu.mover_membros_pos_amistoso(self.bot, canal_voz)

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.channel.id != AMISTOSOS_CHANNEL_ID:
            return
        info = self.amistoso_map.pop(message.id, None)
        if info is None:
            return
        canal_id, canal_voz_id = info

        canal = self.bot.get_channel(canal_id)
        if canal:
            await canal.delete(reason="Mensagem do amistoso deletada — canal removido automaticamente.")
            print(f"[AMISTOSO] 🗑️ Canal {canal.name} deletado junto com o anúncio.")

        if canal_voz_id:
            canal_voz = self.bot.get_channel(canal_voz_id)
            if canal_voz:
                await self._mover_membros_pos_amistoso(canal_voz)
                await canal_voz.delete(reason="Mensagem do amistoso deletada — canal de voz removido automaticamente.")
                print(f"[AMISTOSO] 🗑️ Canal de voz {canal_voz.name} deletado junto com o anúncio.")

    @app_commands.command(name="amistoso", description="Anuncia um amistoso no canal de amistosos.")
    @app_commands.checks.has_any_role(*ADMIN_ROLE_IDS)
    @app_commands.describe(
        adversario="Nome do time adversário",
        dia_semana="Dia do amistoso",
        horario="Horário (ex: 20h00)",
        rank1="Cargo do rank principal",
        rank2="Segundo cargo de rank (opcional)",
        rank3="Terceiro cargo de rank (opcional)",
        mais_cargos="Quantos cargos quiser (opcional): marque com @ ou cole os IDs, separados por espaço",
        info_extra="Informações extras (opcional)",
    )
    @app_commands.choices(
        dia_semana=[app_commands.Choice(name=d, value=d) for d in DIAS_SEMANA],
    )
    async def amistoso(
        self,
        interaction: discord.Interaction,
        adversario: str,
        dia_semana: app_commands.Choice[str],
        horario: str,
        rank1: discord.Role,
        rank2: discord.Role = None,
        rank3: discord.Role = None,
        mais_cargos: str = "",
        info_extra: str = "",
    ):
        outros, erro = extrair_cargos_extras(interaction.guild, mais_cargos)
        if erro:
            await interaction.response.send_message(erro, ephemeral=True)
            return
        await criar_amistoso(interaction, adversario, dia_semana.value, horario, rank1, info_extra, rank2, rank3, outros)

    @amistoso.error
    async def amistoso_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingRole):
            await interaction.response.send_message("❌ Apenas **Administradores** podem anunciar amistosos.", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Friendly(bot))
