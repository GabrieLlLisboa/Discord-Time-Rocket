import discord
from discord.ext import commands
from discord import app_commands
from cogs.backup import ler, salvar, agora_str
from cogs.players import CARGOS_RANK
from cogs.whitelist_extras import CARGO_STAFF_WHITELIST_ID, obter_stats as obter_stats_whitelist


# Ranks (com divisão 1/2/3, exceto Super Sonic Legend) + alguns cargos de
# staff que também aparecem no campo "Cargo" do /perfil. Os ranks vêm
# direto de cogs/players.py — fonte única de verdade dos cargos de rank —
# pra nunca ficar desatualizado quando um rank/divisão for adicionado lá.
RANKS_IDS = {c["id"]: (c["emoji"], c["nome"]) for c in CARGOS_RANK}
RANKS_IDS.update({
    1512571913849933956: ("🥇", "Ouro"),
    1513356584946896946: ("📋", "Coach"),
    1513240072139309317: ("🎬", "Editor de vídeo"),
    1511894837790769204: ("🥈", "Sub-Dono"),
})
ADMIN_ROLE_ID = 1511894837790769204


# ── Biografias fixas ─────────────────────────────────────────────────────
# Texto de bio "hard-coded" pra certos usuários específicos, que aparece
# no /perfil deles independente do que estiver salvo em data/perfis.json.
BIOS_FIXAS = {
    1487452210605588592: (
        "Desenvolvedor do BOT, experiente em Python e DevOps. Configurador "
        "principal do servidor do Discord e Ex-SubDono."
    ),
    1421693641184772147: (
        "O maioral, o fundador do projeto Tryharders RL, administra a rede, "
        "os servidores, e traz novas idéias ao projeto."
    ),
    1190705463310942208: (
        "O melhor jogador que temos, inova com suas mecânicas e visão de "
        "jogo, e passa por cima de quem estiver na frente, este é whei."
    ),
}


# ── Destaques fixos ──────────────────────────────────────────────────────
# Títulos "hard-coded" que aparecem SEMPRE no topo dos DESTAQUES do /perfil
# desse usuário (igual a BIOS_FIXAS), além dos destaques que a staff adiciona
# com /destaque-adicionar. Pra mudar, é só editar a lista (um título por linha;
# o emoji é livre) ou copiar o bloco pra outro ID.
DESTAQUES_FIXOS = {
    1487452210605588592: [
        "💻 **Melhor Dev**",
        "⚙️ **Melhor DevOps**",
        "🔐 **Melhor Cibersecurity**",
        "🐍 **Melhor em Python**",
        "🤖 **Criador do Bot**",
        "🛠️ **Melhor Configurador de Servidor**",
    ],
}


def obter_rank(member: discord.Member) -> str:
    for role in member.roles:
        if role.id in RANKS_IDS:
            emoji, nome = RANKS_IDS[role.id]
            return f"{emoji} {nome}"
    return "Sem cargo"


def garantir_perfil(member_id: int, member_name: str):
    """Garante que o perfil existe e tem todos os campos usados pelo /perfil
    (perfis criados antes de campos novos existirem não tinham esses campos —
    mesmo padrão de defesa usado em cogs/medalhas.py)."""
    perfis = ler("perfis")
    sid = str(member_id)
    if sid not in perfis:
        perfis[sid] = {"nome": member_name, "amistosos": 0, "vitorias": 0, "derrotas": 0}
    dados = perfis[sid]
    dados.setdefault("amistosos", 0)
    dados.setdefault("vitorias", 0)
    dados.setdefault("derrotas", 0)
    dados.setdefault("divisao", None)
    dados.setdefault("titulo", None)
    dados.setdefault("mvps", 0)
    dados.setdefault("destaques", [])
    salvar("perfis", perfis)
    return perfis


class Stats(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot


    @app_commands.command(name="perfil", description="Veja o perfil de um jogador.")
    @app_commands.describe(membro="Jogador que deseja consultar (deixe vazio para ver o seu)")
    async def perfil(self, interaction: discord.Interaction, membro: discord.Member = None):
        membro = membro or interaction.user
        perfis = garantir_perfil(membro.id, membro.display_name)
        dados  = perfis.get(str(membro.id), {})

        rank         = obter_rank(membro)
        divisao      = dados.get("divisao") or "—"
        titulo       = dados.get("titulo") or "—"
        amistosos    = dados.get("amistosos", 0)
        vitorias     = dados.get("vitorias",  0)
        derrotas     = dados.get("derrotas",  0)
        mvps         = dados.get("mvps", 0)
        destaques    = dados.get("destaques", [])
        entrou_em    = discord.utils.format_dt(membro.joined_at, style="D") if membro.joined_at else "Desconhecido"
        conta_criada = discord.utils.format_dt(membro.created_at, style="D")

        winrate = f"{round((vitorias / amistosos) * 100)}%" if amistosos > 0 else "—"

        # fixos (do código) primeiro, depois os últimos 5 que a staff adicionou
        linhas_destaques = list(DESTAQUES_FIXOS.get(membro.id, [])) + [f"⭐ {d}" for d in destaques[-5:]]
        if linhas_destaques:
            destaques_txt = "\n".join(linhas_destaques)
            if len(destaques_txt) > 1024:  # limite do Discord por campo
                destaques_txt = destaques_txt[:1021] + "…"
        else:
            destaques_txt = "_Nenhum destaque registrado ainda._"

        embed = discord.Embed(
            title=f"👤  {membro.display_name}",
            description=f"🏵️  **{titulo}**" if titulo != "—" else None,
            color=0xD4A843,
        )
        embed.set_thumbnail(url=membro.display_avatar.url)

        bio_fixa = BIOS_FIXAS.get(membro.id)
        if bio_fixa:
            embed.add_field(name="📜  Biografia", value=bio_fixa, inline=False)

        embed.add_field(name="\u200b", value="```╔══════════  📋  PERFIL  ══════════╗```", inline=False)
        embed.add_field(name="🏷️  Cargo",          value=rank,         inline=True)
        embed.add_field(name="🎚️  Divisão",        value=divisao,      inline=True)
        embed.add_field(name="📅  Entrou em",       value=entrou_em,    inline=True)
        embed.add_field(name="\u200b", value="```╔══════════  ⚽  DESEMPENHO  ══════════╗```", inline=False)
        embed.add_field(name="🎮  Partidas",   value=f"`{amistosos}`", inline=True)
        embed.add_field(name="✅  Vitórias",   value=f"`{vitorias}`",  inline=True)
        embed.add_field(name="❌  Derrotas",   value=f"`{derrotas}`",  inline=True)
        embed.add_field(name="📊  Winrate",    value=f"`{winrate}`",   inline=True)
        embed.add_field(name="🌟  MVPs",       value=f"`{mvps}`",      inline=True)
        embed.add_field(name="\u200b", value="```╔══════════  ⭐  DESTAQUES  ══════════╗```", inline=False)
        embed.add_field(name="\u200b", value=destaques_txt, inline=False)

        # clips: medalhas e números do concurso "Clip do Mês" (cogs/clips.py)
        clips = dados.get("clips") or {}
        if clips.get("vitorias") or clips.get("finais") or clips.get("enviados"):
            nomes_medalhas_clips = {
                "melhor_clip_mes": "🎬 Melhor Clip (Mês)",
                "finalista_clips": "🏅 Finalista de Clips",
                "clipador":        "🎞️ Clipador",
            }
            medalhas_clips = [n for mid, n in nomes_medalhas_clips.items() if mid in dados.get("medalhas", [])]
            embed.add_field(name="\u200b", value="```╔══════════  🎬  CLIPS  ══════════╗```", inline=False)
            if medalhas_clips:
                embed.add_field(name="🎖️  Medalhas", value="\n".join(medalhas_clips), inline=False)
            embed.add_field(name="🏆  Melhor Clip (Mês)", value=f"`×{clips.get('vitorias', 0)}`", inline=True)
            embed.add_field(
                name="🔥  Sequência",
                value=f"`{clips.get('sequencia_atual', 0)}` (recorde `{clips.get('melhor_sequencia', 0)}`)",
                inline=True,
            )
            embed.add_field(name="🏅  Finais", value=f"`{clips.get('finais', 0)}`", inline=True)
            embed.add_field(name="🎞️  Clips enviados", value=f"`{clips.get('enviados', 0)}`", inline=True)

        # amistoso interno: vitórias/derrotas por modo (cogs/interno.py)
        interno = dados.get("interno") or {}
        modos_jogados = [
            (modo, interno[modo]) for modo in ("1v1", "2v2", "3v3")
            if isinstance(interno.get(modo), dict)
            and (interno[modo].get("vitorias", 0) + interno[modo].get("derrotas", 0)) > 0
        ]
        if modos_jogados:
            embed.add_field(name="\u200b", value="```╔══════════  ⚔️  INTERNO  ══════════╗```", inline=False)
            for modo, d in modos_jogados:
                v, der = d.get("vitorias", 0), d.get("derrotas", 0)
                wr = round(v / (v + der) * 100)
                embed.add_field(
                    name=f"⚔️  {modo}",
                    value=f"`{v}V {der}D`\n📊 {wr}%",
                    inline=True,
                )

        # staff da whitelist: quantas whitelists já aprovou/recusou
        if any(r.id == CARGO_STAFF_WHITELIST_ID for r in membro.roles):
            aprovadas, recusadas = obter_stats_whitelist(membro.id)
            embed.add_field(name="\u200b", value="```╔══════════  🛡️  WHITELIST  ══════════╗```", inline=False)
            embed.add_field(name="✅  Aprovadas", value=f"`{aprovadas}`", inline=True)
            embed.add_field(name="❌  Recusadas", value=f"`{recusadas}`", inline=True)
            embed.add_field(name="📋  Total", value=f"`{aprovadas + recusadas}`", inline=True)
        embed.set_footer(text=f"TryHarders RL • {agora_str()}")

        await interaction.response.send_message(embed=embed)


    @app_commands.command(name="historico", description="Veja o histórico de amistosos registrados.")
    async def historico(self, interaction: discord.Interaction):
        amistosos = ler("amistosos")

        if not amistosos:
            await interaction.response.send_message(
                "📭 Nenhum amistoso registrado ainda.", ephemeral=True
            )
            return

        embed = discord.Embed(
            title="📋  Histórico de Amistosos",
            color=0xD4A843,
        )

        for a in amistosos[-10:][::-1]:
            resultado = a.get("resultado", "⏳ Aguardando")
            placar    = a.get("placar", "")
            valor = (
                f"📅 {a['data']}  |  {a['rank']}\n"
                f"{resultado}{' — ' + placar if placar else ''}"
            )
            embed.add_field(
                name=f"🆚  TryHarders vs {a['adversario']}",
                value=valor,
                inline=False,
            )

        embed.set_footer(text=f"Mostrando os últimos {min(len(amistosos), 10)} amistosos")
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Stats(bot))
